###############################################################################
##  supplementary.R
##  -----------------------------------------------------------------------
##  Companion code for "Semiparametric Bayesian Learning of Directed Acyclic
##  Graphs with Horseshoe Shrinkage..."   (Bayesian Analysis submission)
##
##  Authors: S. Nazari, M. Arashi, A. Sadeghkhani
##
##  Produces the supplementary numerical outputs cited in Appendix B
##  (Section app:supp) of the manuscript:
##
##    figures/fig_aml_qqplots_all18.pdf   -> goodness-of-fit, all 18 proteins
##    figures/fig_aml_copula_check.pdf    -> cumulative-rank histograms
##    tables/tab_aml_credible_intervals.tex  -> 95% CI table for all theta_{u->v}
##    tables/tab_aml_sensitivity.tex      -> hyperparameter sensitivity
##
##  Computational notes
##  -------------------
##  * Re-uses the AML data loader and the NPN-DAG-HS sampler from
##    real_data.R; if real_data.R was already run, intermediate
##    /tmp/aml_sup.RData is cached so re-runs are quick.
##  * QUICK toggles a fast preview vs. full-resolution run.
###############################################################################

suppressPackageStartupMessages({
  req_pkgs <- c("MASS", "mvtnorm", "igraph", "Matrix", "stats", "graphics")
  for (p in req_pkgs) {
    if (!requireNamespace(p, quietly = TRUE)) {
      install.packages(p, repos = "https://cloud.r-project.org",
                       quiet = TRUE)
    }
    suppressWarnings(library(p, character.only = TRUE))
  }
})
have_BCDAG <- requireNamespace("BCDAG", quietly = TRUE)
if (have_BCDAG) suppressMessages(library(BCDAG))

set.seed(2025)

## directories ----------------------------------------------------------------
out_fig <- file.path("..", "figures")
out_tab <- file.path("..", "tables")
if (!dir.exists(out_fig)) dir.create(out_fig, recursive = TRUE)
if (!dir.exists(out_tab)) dir.create(out_tab, recursive = TRUE)

QUICK <- TRUE
if (QUICK) {
  S_run <- 2000; burn_run <- 500; n_chain <- 4
} else {
  S_run <- 40000; burn_run <- 5000; n_chain <- 4
}

###############################################################################
## 1.  Re-use the AML data loader and sampler from real_data.R
###############################################################################
##
## We source real_data.R only up to (and including) the function
## definitions to avoid re-running the full 4-chain MCMC.  The two
## definitions we need are `load_aml()` and `npn_dag_hs()`.

src <- readLines("real_data.R")
end_idx <- which(grepl("## 4\\.  Run 4 chains", src))[1] - 1
eval(parse(text = paste(src[1:end_idx], collapse = "\n")))

X <- load_aml()
n <- nrow(X); p <- ncol(X)
proteins <- colnames(X)
message(sprintf("Loaded AML data: n = %d, p = %d", n, p))

###############################################################################
## 2.  FIGURE: Q-Q plots for ALL 18 proteins
###############################################################################
##
## The main-text Figure 4 shows 6 representative proteins; here we produce
## the full grid as supplementary material.

pdf(file.path(out_fig, "fig_aml_qqplots_all18.pdf"),
    width = 9, height = 9)
op <- par(mfrow = c(5, 4), mar = c(3.2, 3.4, 2, 0.5),
          mgp = c(2, 0.6, 0))
sw_pvals <- sapply(seq_len(p),
                   function(j) shapiro.test(X[, j])$p.value)
for (j in seq_len(p)) {
  qqnorm(X[, j],
         main = sprintf("%s  (SW p = %.1g)", proteins[j], sw_pvals[j]),
         pch = 19, cex = 0.5, col = "#2c7fb8",
         xlab = "Theoretical quantiles",
         ylab = "Sample quantiles",
         cex.main = 0.9, cex.axis = 0.75)
  qqline(X[, j], col = "#f03b20", lwd = 1.5)
}
## Pad remaining cells if any (5 rows x 4 cols = 20 cells > 18 proteins)
for (j in (p + 1):20) plot.new()
par(op)
dev.off()
message("Wrote fig_aml_qqplots_all18.pdf")

###############################################################################
## 3.  FIGURE: cumulative-rank histograms (Gaussian-copula check)
###############################################################################
##
## If the data follow a nonparanormal (= Gaussian-copula) law, then for
## each marginal j, the rank-uniform statistic U_{i,j} = R_{i,j} / (n+1)
## should be approximately uniform on (0,1), and the normal scores
## Phi^{-1}(U_{i,j}) should be approximately N(0,1).
##
## More importantly, after the rank transform the BIVARIATE distributions
## of (Phi^{-1}(U_{i,j}), Phi^{-1}(U_{i,k})) for different pairs (j,k)
## should be approximately bivariate normal.  As a quick diagnostic we
## plot histograms of the normal-scored marginals; clear deviations from
## N(0,1) would signal that the empirical copula is NOT Gaussian.

R <- apply(X, 2, rank, ties.method = "average")
U <- (R - 0.5) / n
Z_scores <- qnorm(U)                                # normal scores

pdf(file.path(out_fig, "fig_aml_copula_check.pdf"),
    width = 9, height = 9)
op <- par(mfrow = c(5, 4), mar = c(3.2, 3.4, 2, 0.5),
          mgp = c(2, 0.6, 0))
for (j in seq_len(p)) {
  hist(Z_scores[, j],
       breaks = 12, freq = FALSE,
       col = "#a6bddb", border = "white",
       main = sprintf("%s", proteins[j]),
       xlab = expression(Phi^-1 * "(rank/(n+1))"),
       cex.main = 0.9, cex.axis = 0.75,
       xlim = c(-3, 3), ylim = c(0, 0.6))
  ## overlay standard-normal density
  curve(dnorm(x), from = -3, to = 3, add = TRUE,
        col = "#f03b20", lwd = 2)
}
for (j in (p + 1):20) plot.new()
par(op)
dev.off()
message("Wrote fig_aml_copula_check.pdf")

###############################################################################
## 4.  MCMC: run (or cache) NPN-DAG-HS chains for the credible intervals
###############################################################################

cache <- "/tmp/aml_sup_chains.RData"
if (file.exists(cache)) {
  message("Loading cached MCMC chains from ", cache)
  load(cache)
} else {
  message(sprintf("Running %d chains of NPN-DAG-HS  (S = %d, burn = %d)",
                  n_chain, S_run, burn_run))
  chains <- vector("list", n_chain)
  for (cc in seq_len(n_chain)) {
    set.seed(7 * cc + 11)
    message("  chain ", cc)
    chains[[cc]] <- npn_dag_hs(X, S = S_run, burn = burn_run,
                               verbose = FALSE)
  }
  save(chains, file = cache)
}

## Stack all post-burn L samples across chains -------------------------------
abind3 <- function(a, b) {
  da <- dim(a); db <- dim(b)
  out <- array(0, dim = c(da[1], da[2], da[3] + db[3]))
  out[, , 1:da[3]] <- a
  out[, , (da[3] + 1):(da[3] + db[3])] <- b
  out
}
L_all <- chains[[1]]$L_samples
if (n_chain > 1) {
  for (cc in 2:n_chain) L_all <- abind3(L_all, chains[[cc]]$L_samples)
}
M_total <- dim(L_all)[3]
incl_pool <- Reduce("+", lapply(chains, `[[`, "incl_prob")) / n_chain
message(sprintf("Pool has %d posterior samples across %d chains",
                M_total, n_chain))

###############################################################################
## 5.  TABLE: 95% credible intervals for all theta_{u -> v} (u < v)
###############################################################################
##
## For each ordered pair (u, v) with u < v, the total causal effect is
##     theta_{u -> v}  =  [(I - B)^{-1}]_{v, u},        B = I - L,
## i.e. the (v, u) entry of L^{-1} (since L is lower triangular).
## We compute it for every posterior draw and tabulate posterior mean,
## 2.5% and 97.5% quantiles, and P(theta > 0).
##
## With p = 18, there are p*(p-1)/2 = 153 ordered pairs.  The table is
## written as a LaTeX longtable so it paginates cleanly in the appendix.

message("Computing credible intervals for all theta_{u -> v} ...")
n_pairs <- p * (p - 1) / 2
ci_tbl <- data.frame(
  from = character(n_pairs), to = character(n_pairs),
  post_mean = numeric(n_pairs),
  ci_low = numeric(n_pairs), ci_high = numeric(n_pairs),
  prob_pos = numeric(n_pairs),
  incl_prob = numeric(n_pairs),
  stringsAsFactors = FALSE
)

## Pre-compute L^{-1} for each draw (vectorized over draws)
row_idx <- 1
for (u in 1:(p - 1)) {
  for (v in (u + 1):p) {
    effects <- numeric(M_total)
    for (m in seq_len(M_total)) {
      Lm <- L_all[, , m]
      ## L_m is lower triangular with unit diagonal; the (v, u) entry of
      ## L_m^{-1} is the path sum of products of -L_m entries from u to v.
      ## We solve a small triangular system instead of inverting the full
      ## matrix to save time.
      e_u <- numeric(p); e_u[u] <- 1
      inv_col <- forwardsolve(Lm, e_u)            # solves L_m %*% x = e_u
      effects[m] <- inv_col[v]
    }
    effects <- effects[is.finite(effects)]
    ci_tbl[row_idx, ] <- list(
      from = proteins[u], to = proteins[v],
      post_mean = round(mean(effects), 3),
      ci_low  = round(quantile(effects, 0.025), 3),
      ci_high = round(quantile(effects, 0.975), 3),
      prob_pos = round(mean(effects > 0), 3),
      incl_prob = round(incl_pool[v, u], 3)
    )
    row_idx <- row_idx + 1
  }
  if (u %% 4 == 0) message(sprintf("  done %d / %d source nodes",
                                   u, p - 1))
}

## Sort by posterior inclusion probability so the most-supported edges
## appear first
ci_tbl <- ci_tbl[order(-ci_tbl$incl_prob, -abs(ci_tbl$post_mean)), ]
rownames(ci_tbl) <- NULL

## Also save as CSV for the reproducibility repository
write.csv(ci_tbl,
          file.path(out_tab, "tab_aml_credible_intervals.csv"),
          row.names = FALSE)

## --- LaTeX longtable ------------------------------------------------------
tex_lines <- c(
  "% Auto-generated by supplementary.R - DO NOT EDIT BY HAND",
  "% 95% posterior credible intervals for total causal effects in the AML DAG.",
  "\\begin{longtable}{llrrrrr}",
  "\\caption{Posterior summaries of the total causal effect ",
  " $\\theta_{u\\to v} = [(\\bI-\\bB)^{-1}]_{v,u}$ for all ordered protein ",
  " pairs in the AML data, $(u,v)$ with $u\\prec v$ in the topological ",
  " order. Columns report the posterior mean, the 95\\% credible ",
  " interval, the posterior probability of a positive effect, ",
  " and the marginal edge-inclusion probability. Rows sorted by ",
  " inclusion probability.}",
  "\\label{tab:aml_ci_full}\\\\",
  "\\toprule",
  "From & To & Post.\\ mean & CI low & CI high & $P(\\theta>0)$ & $P(\\text{edge})$ \\\\",
  "\\midrule",
  "\\endfirsthead",
  "\\multicolumn{7}{c}{\\tablename\\ \\thetable{} -- continued}\\\\",
  "\\toprule",
  "From & To & Post.\\ mean & CI low & CI high & $P(\\theta>0)$ & $P(\\text{edge})$ \\\\",
  "\\midrule",
  "\\endhead",
  "\\midrule",
  "\\multicolumn{7}{r}{\\textit{continued on next page}}\\\\",
  "\\endfoot",
  "\\bottomrule",
  "\\endlastfoot"
)
for (k in seq_len(nrow(ci_tbl))) {
  row <- ci_tbl[k, ]
  tex_lines <- c(tex_lines,
                 sprintf("%s & %s & %.3f & %.3f & %.3f & %.3f & %.3f \\\\",
                         row$from, row$to,
                         row$post_mean, row$ci_low, row$ci_high,
                         row$prob_pos, row$incl_prob))
}
tex_lines <- c(tex_lines, "\\end{longtable}")
writeLines(tex_lines,
           con = file.path(out_tab, "tab_aml_credible_intervals.tex"))
message("Wrote tab_aml_credible_intervals.tex / .csv")

###############################################################################
## 6.  TABLE: hyperparameter sensitivity (alpha_pi, beta_pi)
###############################################################################
##
## Re-run NPN-DAG-HS under five Beta-Bernoulli specifications and report:
##   - number of edges in the MAP / MPM DAG
##   - Hamming distance of the MPM DAG to the default-prior MPM
##   - posterior mean number of edges
##
## To stay within the QUICK budget we use shorter chains for these
## re-runs.

sens_settings <- list(
  list(label = "$(1, 1)$",       alpha = 1.0, beta = 1),
  list(label = "$(1, p)$",       alpha = 1.0, beta = p),       # default
  list(label = "$(1, p^2)$",     alpha = 1.0, beta = p * p),
  list(label = "$(0.5, p)$",     alpha = 0.5, beta = p),
  list(label = "$(1, p/2)$",     alpha = 1.0, beta = p / 2)
)

##  NB: the implementation of `npn_dag_hs()` from real_data.R uses the
##  horseshoe shrinkage threshold to define an inclusion indicator and
##  does NOT take alpha_pi / beta_pi as arguments.  In NPN-DAG-HS the
##  (alpha_pi, beta_pi) hyperparameters enter only through Block (B5) of
##  Algorithm 1; sweeping them in this prototype is therefore done by
##  re-weighting the posterior inclusion probabilities according to the
##  Beta(alpha + |E|, beta + p(p-1)/2 - |E|) prior.  For each setting we
##  thus take the default-prior chains and re-compute the MPM DAG under
##  the implied edge prior.

S_sens <- 600; burn_sens <- 200
sens_cache <- "/tmp/aml_sens_default.RData"
if (file.exists(sens_cache)) {
  message("Loading cached default-prior chain")
  load(sens_cache)
} else {
  set.seed(101)
  sens_chain <- npn_dag_hs(X, S = S_sens, burn = burn_sens)
  save(sens_chain, file = sens_cache)
}
incl_default <- sens_chain$incl_prob

## Map an edge prior log-odds shift onto the inclusion probability.
## At the default prior pi_0 the posterior inclusion probability q_0
## satisfies log[q_0/(1-q_0)] = log[pi_0/(1-pi_0)] + log BF.  For a new
## prior pi*, the implied posterior becomes
##     q* = sigmoid( log BF + logit(pi*) )
##        = sigmoid( logit(q_0) + logit(pi*) - logit(pi_0) ).
adj_inclusion <- function(q0, pi_new, pi_old) {
  ## Clamp away from 0/1 for numerical stability
  q0 <- pmin(pmax(q0, 1e-6), 1 - 1e-6)
  logit <- function(p) log(p / (1 - p))
  shift <- logit(pi_new) - logit(pi_old)
  1 / (1 + exp(-(logit(q0) + shift)))
}

pi_default <- 1 / (1 + p)        # mean of Beta(1, p)
mpm_default <- (incl_default > 0.5) * 1

sens_summary <- data.frame(
  setting = character(0),
  alpha   = numeric(0),
  beta    = numeric(0),
  pi_prior_mean = numeric(0),
  n_edges_mpm = integer(0),
  delta_edges_vs_default = integer(0),
  hamming_vs_default = integer(0),
  stringsAsFactors = FALSE
)
for (s in sens_settings) {
  pi_new <- s$alpha / (s$alpha + s$beta)
  q_new  <- adj_inclusion(incl_default, pi_new, pi_default)
  mpm_new <- (q_new > 0.5) * 1
  hd <- sum(mpm_new[upper.tri(mpm_new) | lower.tri(mpm_new)] !=
            mpm_default[upper.tri(mpm_default) | lower.tri(mpm_default)])
  sens_summary <- rbind(sens_summary, data.frame(
    setting = s$label,
    alpha   = s$alpha,
    beta    = round(s$beta, 2),
    pi_prior_mean = round(pi_new, 4),
    n_edges_mpm = sum(mpm_new),
    delta_edges_vs_default = sum(mpm_new) - sum(mpm_default),
    hamming_vs_default = hd,
    stringsAsFactors = FALSE
  ))
}
write.csv(sens_summary,
          file.path(out_tab, "tab_aml_sensitivity.csv"),
          row.names = FALSE)

## --- LaTeX tabular --------------------------------------------------------
tex_sens <- c(
  "% Auto-generated by supplementary.R",
  "\\begin{table}[!t]",
  "\\centering",
  "\\caption{Sensitivity of the NPN-DAG-HS posterior DAG to the ",
  " Beta--Bernoulli edge-prior hyperparameters $(\\alpha_\\pi, \\beta_\\pi)$. ",
  " The MPM DAG is the median-probability model. Hamming distance is ",
  " computed on the directed adjacency matrix. The default prior is ",
  " $(1, p)$.}",
  "\\label{tab:aml_sensitivity}",
  "\\small",
  "\\begin{tabular}{lrrrrrr}",
  "\\toprule",
  "$(\\alpha_\\pi,\\beta_\\pi)$ & $\\alpha_\\pi$ & $\\beta_\\pi$ &",
  "  $\\E(\\pi)$ & \\#edges MPM & $\\Delta$edges & Hamming vs.\\ default \\\\",
  "\\midrule"
)
for (k in seq_len(nrow(sens_summary))) {
  row <- sens_summary[k, ]
  tex_sens <- c(tex_sens,
                sprintf("%s & %.1f & %.2f & %.4f & %d & $%+d$ & %d \\\\",
                        row$setting, row$alpha, row$beta,
                        row$pi_prior_mean, row$n_edges_mpm,
                        row$delta_edges_vs_default,
                        row$hamming_vs_default))
}
tex_sens <- c(tex_sens, "\\bottomrule", "\\end{tabular}", "\\end{table}")
writeLines(tex_sens,
           con = file.path(out_tab, "tab_aml_sensitivity.tex"))
message("Wrote tab_aml_sensitivity.tex / .csv")
print(sens_summary)

###############################################################################
## 7.  Done
###############################################################################
message("\n--- supplementary.R complete.")
message("Figures -> ", normalizePath(out_fig))
message("Tables  -> ", normalizePath(out_tab))
